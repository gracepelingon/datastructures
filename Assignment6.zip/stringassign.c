#include<stdio.h>
void main()
{
    char lower[50];

    printf("Enter a string: ");
    gets(lower);

    printf("String equivalent to upper case is: %s",strupr(lower));
}
