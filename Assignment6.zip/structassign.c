#include<stdio.h>
struct cricketer
{
    char name[50];
    int age;
    int test;
    int roll;
    float average;
};
void main(){
    struct cricketer a[10];
    int i;
    for(i=0;i<10;++i)
    {
        a[i].roll=i+1;
        printf("For roll number %d \n", a[i].roll);
        printf("Enter name: ");
        scanf("%s", a[i].name);
        printf("Enter your age: ");
        scanf("%d", &a[i].age);
        printf("Enter your test matches: ");
        scanf("%d", &a[i].test);
        printf("Enter your average runs: ");
        scanf("%f", &a[i].average);
        printf("\n");
    }
    printf("Displayed information of cricketer");
    for(i=0;i<10;++i)
    {
        printf("\nInformation for roll number %d: ", i+1);
        printf("Name: ");
        puts(a[i].name);
        printf("Age: %d \n", a[i].age);
        printf("Test matches: %d \n", a[i].test);
        printf("Average runs: %.lf \n", a[i].average);
    }
}
